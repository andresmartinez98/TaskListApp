export interface TaskResponse {
  id:           number;
  description:  string;
  isCompleted:  boolean;
  creationDate: string;
  dueDate:      string;
}
